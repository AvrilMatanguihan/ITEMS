import { storage } from "./storage";

export async function seedDatabase() {
  console.log("Seeding database with sample data...");

  try {
    // Create sample employees
    const employees = [
      {
        fullName: "Kenji Tanaka",
        email: "kenji.tanaka@yamaha.com",
        department: "IT Department",
        position: "Senior IT Manager",
        employeeId: "YMH001",
        status: "active" as const,
      },
      {
        fullName: "Maria Rodriguez",
        email: "maria.rodriguez@yamaha.com",
        department: "Engineering",
        position: "Software Engineer",
        employeeId: "YMH002",
        status: "active" as const,
      },
      {
        fullName: "David Chen",
        email: "david.chen@yamaha.com",
        department: "Marketing",
        position: "Marketing Specialist",
        employeeId: "YMH003",
        status: "active" as const,
      },
      {
        fullName: "Sarah Johnson",
        email: "sarah.johnson@yamaha.com",
        department: "HR",
        position: "HR Coordinator",
        employeeId: "YMH004",
        status: "active" as const,
      },
      {
        fullName: "Hiroshi Yamamoto",
        email: "hiroshi.yamamoto@yamaha.com",
        department: "R&D",
        position: "Research Engineer",
        employeeId: "YMH005",
        status: "active" as const,
      },
    ];

    const createdEmployees = [];
    for (const employee of employees) {
      const created = await storage.createEmployee(employee);
      createdEmployees.push(created);
      console.log(`Created employee: ${created.fullName}`);
    }

    // Create sample equipment
    const equipment = [
      {
        itemName: "MacBook Pro 16-inch",
        brand: "Apple",
        model: "M2 Pro",
        category: "laptop",
        serialNumber: "YMH-LT-001",
        assignedToId: createdEmployees[0].id,
        condition: "new",
        status: "active",
        purchaseDate: "2024-01-15",
        remarks: "High-performance laptop for development work",
      },
      {
        itemName: "Dell XPS 13",
        brand: "Dell",
        model: "XPS 13 9320",
        category: "laptop",
        serialNumber: "YMH-LT-002",
        assignedToId: createdEmployees[1].id,
        condition: "good",
        status: "active",
        purchaseDate: "2023-08-20",
        remarks: "Compact laptop for software development",
      },
      {
        itemName: "HP EliteDesk 800",
        brand: "HP",
        model: "G9 Mini",
        category: "desktop",
        serialNumber: "YMH-DT-001",
        assignedToId: createdEmployees[2].id,
        condition: "good",
        status: "active",
        purchaseDate: "2023-06-10",
        remarks: "Desktop workstation for marketing team",
      },
      {
        itemName: "iPad Pro",
        brand: "Apple",
        model: "12.9-inch M2",
        category: "tablet",
        serialNumber: "YMH-TB-001",
        assignedToId: createdEmployees[3].id,
        condition: "new",
        status: "active",
        purchaseDate: "2024-02-01",
        remarks: "Tablet for mobile presentations and note-taking",
      },
      {
        itemName: "ThinkPad X1 Carbon",
        brand: "Lenovo",
        model: "Gen 11",
        category: "laptop",
        serialNumber: "YMH-LT-003",
        assignedToId: createdEmployees[4].id,
        condition: "good",
        status: "active",
        purchaseDate: "2023-11-15",
        remarks: "Lightweight laptop for research work",
      },
      {
        itemName: "Dell UltraSharp 27",
        brand: "Dell",
        model: "U2723QE",
        category: "monitor",
        serialNumber: "YMH-MN-001",
        assignedToId: null,
        condition: "new",
        status: "available",
        purchaseDate: "2024-01-20",
        remarks: "4K monitor for design work",
      },
      {
        itemName: "HP LaserJet Pro",
        brand: "HP",
        model: "M404n",
        category: "printer",
        serialNumber: "YMH-PR-001",
        assignedToId: null,
        condition: "good",
        status: "available",
        purchaseDate: "2023-09-05",
        remarks: "Network printer for office use",
      },
      {
        itemName: "MacBook Air",
        brand: "Apple",
        model: "M1 13-inch",
        category: "laptop",
        serialNumber: "YMH-LT-004",
        assignedToId: null,
        condition: "fair",
        status: "maintenance",
        purchaseDate: "2022-03-10",
        remarks: "Requires battery replacement",
      },
      {
        itemName: "Cisco Switch",
        brand: "Cisco",
        model: "SG350-28",
        category: "networking",
        serialNumber: "YMH-NW-001",
        assignedToId: null,
        condition: "good",
        status: "active",
        purchaseDate: "2023-07-12",
        remarks: "28-port managed switch for main office",
      },
      {
        itemName: "iPhone 14 Pro",
        brand: "Apple",
        model: "128GB",
        category: "phone",
        serialNumber: "YMH-PH-001",
        assignedToId: createdEmployees[0].id,
        condition: "new",
        status: "active",
        purchaseDate: "2024-01-05",
        remarks: "Company phone for management",
      },
    ];

    const createdEquipment = [];
    for (const item of equipment) {
      const created = await storage.createEquipment(item);
      createdEquipment.push(created);
      console.log(`Created equipment: ${created.itemName}`);
    }

    // Create sample maintenance schedules
    const maintenanceSchedules = [
      {
        equipmentId: createdEquipment[7].id, // MacBook Air with battery issues
        maintenanceType: "repair",
        scheduledDate: "2024-06-05",
        description: "Replace battery and run diagnostic tests",
        status: "scheduled",
        performedBy: "TechCorp Services",
        notes: "Customer reported poor battery life",
      },
      {
        equipmentId: createdEquipment[6].id, // HP Printer
        maintenanceType: "preventive",
        scheduledDate: "2024-06-15",
        description: "Routine cleaning and toner replacement",
        status: "scheduled",
        performedBy: "HP Service Team",
        notes: "Quarterly maintenance schedule",
      },
      {
        equipmentId: createdEquipment[8].id, // Cisco Switch
        maintenanceType: "inspection",
        scheduledDate: "2024-06-20",
        description: "Firmware update and security audit",
        status: "scheduled",
        performedBy: "IT Department",
        notes: "Regular security compliance check",
      },
    ];

    for (const schedule of maintenanceSchedules) {
      const created = await storage.createMaintenanceSchedule(schedule);
      console.log(`Created maintenance schedule: ${schedule.description}`);
    }

    console.log("Database seeding completed successfully!");
    return {
      employees: createdEmployees,
      equipment: createdEquipment,
      message: "Sample data created successfully"
    };

  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}