import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertEquipmentSchema, 
  insertEmployeeSchema, 
  insertMaintenanceScheduleSchema,
  insertEquipmentHistorySchema 
} from "@shared/schema";
import { seedDatabase } from "./seed-data";

export function registerRoutes(app: Express): Server {
  // Setup authentication routes
  setupAuth(app);

  // Equipment routes
  app.get("/api/equipment", async (req, res) => {
    try {
      const equipmentList = await storage.getEquipment();
      res.json(equipmentList);
    } catch (error) {
      console.error("Error fetching equipment:", error);
      res.status(500).json({ message: "Failed to fetch equipment" });
    }
  });

  app.get("/api/equipment/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      const equipmentList = await storage.searchEquipment(query);
      res.json(equipmentList);
    } catch (error) {
      console.error("Error searching equipment:", error);
      res.status(500).json({ message: "Failed to search equipment" });
    }
  });

  app.get("/api/equipment/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const equipment = await storage.getEquipmentById(id);
      if (!equipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }
      res.json(equipment);
    } catch (error) {
      console.error("Error fetching equipment:", error);
      res.status(500).json({ message: "Failed to fetch equipment" });
    }
  });

  app.post("/api/equipment", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const validatedData = insertEquipmentSchema.parse(req.body);
      const equipment = await storage.createEquipment(validatedData);

      // Create history entry
      await storage.createEquipmentHistory({
        equipmentId: equipment.id,
        action: "created",
        performedBy: req.user!.id,
        description: `Equipment created: ${equipment.itemName}`,
      });

      res.status(201).json(equipment);
    } catch (error) {
      console.error("Error creating equipment:", error);
      res.status(400).json({ message: "Failed to create equipment" });
    }
  });

  app.put("/api/equipment/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const id = parseInt(req.params.id);
      const validatedData = insertEquipmentSchema.partial().parse(req.body);
      const equipment = await storage.updateEquipment(id, validatedData);

      // Create history entry
      await storage.createEquipmentHistory({
        equipmentId: equipment.id,
        action: "updated",
        performedBy: req.user!.id,
        description: `Equipment updated: ${equipment.itemName}`,
      });

      res.json(equipment);
    } catch (error) {
      console.error("Error updating equipment:", error);
      res.status(400).json({ message: "Failed to update equipment" });
    }
  });

  app.delete("/api/equipment/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const id = parseInt(req.params.id);
      const equipment = await storage.getEquipmentById(id);
      if (!equipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }

      await storage.deleteEquipment(id);

      // Create history entry
      await storage.createEquipmentHistory({
        equipmentId: id,
        action: "deleted",
        performedBy: req.user!.id,
        description: `Equipment deleted: ${equipment.itemName}`,
      });

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting equipment:", error);
      res.status(400).json({ message: "Failed to delete equipment" });
    }
  });

  // Equipment assignment routes
  app.post("/api/equipment/:id/assign", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const equipmentId = parseInt(req.params.id);
      const { employeeId } = req.body;

      const equipment = await storage.getEquipmentById(equipmentId);
      if (!equipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }

      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }

      const updatedEquipment = await storage.updateEquipment(equipmentId, {
        assignedToId: employeeId,
        status: "active",
      });

      // Create history entry
      await storage.createEquipmentHistory({
        equipmentId: equipmentId,
        action: "assigned",
        toEmployeeId: employeeId,
        performedBy: req.user!.id,
        description: `Equipment assigned to ${employee.fullName}`,
      });

      res.json(updatedEquipment);
    } catch (error) {
      console.error("Error assigning equipment:", error);
      res.status(400).json({ message: "Failed to assign equipment" });
    }
  });

  app.post("/api/equipment/:id/return", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const equipmentId = parseInt(req.params.id);

      const equipment = await storage.getEquipmentById(equipmentId);
      if (!equipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }

      const fromEmployeeId = equipment.assignedToId;
      const updatedEquipment = await storage.updateEquipment(equipmentId, {
        assignedToId: null,
        status: "available",
      });

      // Create history entry
      await storage.createEquipmentHistory({
        equipmentId: equipmentId,
        action: "returned",
        fromEmployeeId: fromEmployeeId,
        performedBy: req.user!.id,
        description: `Equipment returned`,
      });

      res.json(updatedEquipment);
    } catch (error) {
      console.error("Error returning equipment:", error);
      res.status(400).json({ message: "Failed to return equipment" });
    }
  });

  // Employee routes
  app.get("/api/employees", async (req, res) => {
    try {
      const employees = await storage.getEmployees();
      res.json(employees);
    } catch (error) {
      console.error("Error fetching employees:", error);
      res.status(500).json({ message: "Failed to fetch employees" });
    }
  });

  app.get("/api/employees/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployee(id);
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      res.json(employee);
    } catch (error) {
      console.error("Error fetching employee:", error);
      res.status(500).json({ message: "Failed to fetch employee" });
    }
  });

  app.post("/api/employees", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const validatedData = insertEmployeeSchema.parse(req.body);
      const employee = await storage.createEmployee(validatedData);
      res.status(201).json(employee);
    } catch (error) {
      console.error("Error creating employee:", error);
      res.status(400).json({ message: "Failed to create employee" });
    }
  });

  app.put("/api/employees/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const id = parseInt(req.params.id);
      const validatedData = insertEmployeeSchema.partial().parse(req.body);
      const employee = await storage.updateEmployee(id, validatedData);
      res.json(employee);
    } catch (error) {
      console.error("Error updating employee:", error);
      res.status(400).json({ message: "Failed to update employee" });
    }
  });

  app.delete("/api/employees/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const id = parseInt(req.params.id);
      await storage.deleteEmployee(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting employee:", error);
      res.status(400).json({ message: "Failed to delete employee" });
    }
  });

  // Maintenance routes
  app.get("/api/maintenance", async (req, res) => {
    try {
      const schedules = await storage.getMaintenanceSchedules();
      res.json(schedules);
    } catch (error) {
      console.error("Error fetching maintenance schedules:", error);
      res.status(500).json({ message: "Failed to fetch maintenance schedules" });
    }
  });

  app.get("/api/maintenance/upcoming", async (req, res) => {
    try {
      const schedules = await storage.getUpcomingMaintenance();
      res.json(schedules);
    } catch (error) {
      console.error("Error fetching upcoming maintenance:", error);
      res.status(500).json({ message: "Failed to fetch upcoming maintenance" });
    }
  });

  app.post("/api/maintenance", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const validatedData = insertMaintenanceScheduleSchema.parse(req.body);
      const schedule = await storage.createMaintenanceSchedule(validatedData);
      res.status(201).json(schedule);
    } catch (error) {
      console.error("Error creating maintenance schedule:", error);
      res.status(400).json({ message: "Failed to create maintenance schedule" });
    }
  });

  app.put("/api/maintenance/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const id = parseInt(req.params.id);
      const validatedData = insertMaintenanceScheduleSchema.partial().parse(req.body);
      const schedule = await storage.updateMaintenanceSchedule(id, validatedData);
      res.json(schedule);
    } catch (error) {
      console.error("Error updating maintenance schedule:", error);
      res.status(400).json({ message: "Failed to update maintenance schedule" });
    }
  });

  app.delete("/api/maintenance/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    try {
      const id = parseInt(req.params.id);
      await storage.deleteMaintenanceSchedule(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting maintenance schedule:", error);
      res.status(400).json({ message: "Failed to delete maintenance schedule" });
    }
  });

  // Equipment history routes
  app.get("/api/equipment/:id/history", async (req, res) => {
    try {
      const equipmentId = parseInt(req.params.id);
      const history = await storage.getEquipmentHistory(equipmentId);
      res.json(history);
    } catch (error) {
      console.error("Error fetching equipment history:", error);
      res.status(500).json({ message: "Failed to fetch equipment history" });
    }
  });

  // Dashboard stats route
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Seed database route (for demo purposes)
  app.post("/api/seed", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const result = await seedDatabase();
      res.json(result);
    } catch (error) {
      console.error("Error seeding database:", error);
      res.status(500).json({ message: "Failed to seed database" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
