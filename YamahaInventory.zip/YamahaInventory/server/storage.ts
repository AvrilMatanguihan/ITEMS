import { 
  users, 
  employees, 
  equipment, 
  maintenanceSchedules, 
  equipmentHistory,
  type User, 
  type InsertUser,
  type Employee,
  type InsertEmployee,
  type Equipment,
  type InsertEquipment,
  type MaintenanceSchedule,
  type InsertMaintenanceSchedule,
  type EquipmentHistory,
  type InsertEquipmentHistory
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, like, or, count, isNull } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Employee methods
  getEmployees(): Promise<Employee[]>;
  getEmployee(id: number): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: number, employee: Partial<InsertEmployee>): Promise<Employee>;
  deleteEmployee(id: number): Promise<void>;

  // Equipment methods
  getEquipment(): Promise<(Equipment & { assignedTo?: Employee })[]>;
  getEquipmentById(id: number): Promise<(Equipment & { assignedTo?: Employee }) | undefined>;
  createEquipment(equipment: InsertEquipment): Promise<Equipment>;
  updateEquipment(id: number, equipment: Partial<InsertEquipment>): Promise<Equipment>;
  deleteEquipment(id: number): Promise<void>;
  searchEquipment(query: string): Promise<(Equipment & { assignedTo?: Employee })[]>;

  // Maintenance methods
  getMaintenanceSchedules(): Promise<(MaintenanceSchedule & { equipment: Equipment })[]>;
  getMaintenanceSchedule(id: number): Promise<(MaintenanceSchedule & { equipment: Equipment }) | undefined>;
  createMaintenanceSchedule(schedule: InsertMaintenanceSchedule): Promise<MaintenanceSchedule>;
  updateMaintenanceSchedule(id: number, schedule: Partial<InsertMaintenanceSchedule>): Promise<MaintenanceSchedule>;
  deleteMaintenanceSchedule(id: number): Promise<void>;
  getUpcomingMaintenance(): Promise<(MaintenanceSchedule & { equipment: Equipment })[]>;

  // Equipment history methods
  getEquipmentHistory(equipmentId: number): Promise<(EquipmentHistory & { 
    fromEmployee?: Employee;
    toEmployee?: Employee;
    performedByUser: User;
  })[]>;
  createEquipmentHistory(history: InsertEquipmentHistory): Promise<EquipmentHistory>;

  // Dashboard stats
  getDashboardStats(): Promise<{
    totalEquipment: number;
    available: number;
    underMaintenance: number;
    upcomingMaintenance: number;
  }>;

  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getEmployees(): Promise<Employee[]> {
    return await db.select().from(employees).orderBy(desc(employees.createdAt));
  }

  async getEmployee(id: number): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.id, id));
    return employee || undefined;
  }

  async createEmployee(insertEmployee: InsertEmployee): Promise<Employee> {
    const [employee] = await db
      .insert(employees)
      .values(insertEmployee)
      .returning();
    return employee;
  }

  async updateEmployee(id: number, updateEmployee: Partial<InsertEmployee>): Promise<Employee> {
    const [employee] = await db
      .update(employees)
      .set(updateEmployee)
      .where(eq(employees.id, id))
      .returning();
    return employee;
  }

  async deleteEmployee(id: number): Promise<void> {
    await db.delete(employees).where(eq(employees.id, id));
  }

  async getEquipment(): Promise<(Equipment & { assignedTo?: Employee })[]> {
    const equipmentWithEmployee = await db
      .select({
        id: equipment.id,
        itemName: equipment.itemName,
        brand: equipment.brand,
        model: equipment.model,
        category: equipment.category,
        serialNumber: equipment.serialNumber,
        assignedToId: equipment.assignedToId,
        condition: equipment.condition,
        status: equipment.status,
        purchaseDate: equipment.purchaseDate,
        remarks: equipment.remarks,
        createdAt: equipment.createdAt,
        updatedAt: equipment.updatedAt,
        assignedTo: employees,
      })
      .from(equipment)
      .leftJoin(employees, eq(equipment.assignedToId, employees.id))
      .orderBy(desc(equipment.createdAt));

    return equipmentWithEmployee.map(item => ({
      ...item,
      assignedTo: item.assignedTo || undefined,
    }));
  }

  async getEquipmentById(id: number): Promise<(Equipment & { assignedTo?: Employee }) | undefined> {
    const [equipmentWithEmployee] = await db
      .select({
        id: equipment.id,
        itemName: equipment.itemName,
        brand: equipment.brand,
        model: equipment.model,
        category: equipment.category,
        serialNumber: equipment.serialNumber,
        assignedToId: equipment.assignedToId,
        condition: equipment.condition,
        status: equipment.status,
        purchaseDate: equipment.purchaseDate,
        remarks: equipment.remarks,
        createdAt: equipment.createdAt,
        updatedAt: equipment.updatedAt,
        assignedTo: employees,
      })
      .from(equipment)
      .leftJoin(employees, eq(equipment.assignedToId, employees.id))
      .where(eq(equipment.id, id));

    if (!equipmentWithEmployee) return undefined;

    return {
      ...equipmentWithEmployee,
      assignedTo: equipmentWithEmployee.assignedTo || undefined,
    };
  }

  async createEquipment(insertEquipment: InsertEquipment): Promise<Equipment> {
    const [newEquipment] = await db
      .insert(equipment)
      .values(insertEquipment)
      .returning();
    return newEquipment;
  }

  async updateEquipment(id: number, updateEquipment: Partial<InsertEquipment>): Promise<Equipment> {
    const [updatedEquipment] = await db
      .update(equipment)
      .set({ ...updateEquipment, updatedAt: new Date() })
      .where(eq(equipment.id, id))
      .returning();
    return updatedEquipment;
  }

  async deleteEquipment(id: number): Promise<void> {
    await db.delete(equipment).where(eq(equipment.id, id));
  }

  async searchEquipment(query: string): Promise<(Equipment & { assignedTo?: Employee })[]> {
    const equipmentWithEmployee = await db
      .select({
        id: equipment.id,
        itemName: equipment.itemName,
        brand: equipment.brand,
        model: equipment.model,
        category: equipment.category,
        serialNumber: equipment.serialNumber,
        assignedToId: equipment.assignedToId,
        condition: equipment.condition,
        status: equipment.status,
        purchaseDate: equipment.purchaseDate,
        remarks: equipment.remarks,
        createdAt: equipment.createdAt,
        updatedAt: equipment.updatedAt,
        assignedTo: employees,
      })
      .from(equipment)
      .leftJoin(employees, eq(equipment.assignedToId, employees.id))
      .where(
        or(
          like(equipment.itemName, `%${query}%`),
          like(equipment.brand, `%${query}%`),
          like(equipment.model, `%${query}%`),
          like(equipment.serialNumber, `%${query}%`)
        )
      )
      .orderBy(desc(equipment.createdAt));

    return equipmentWithEmployee.map(item => ({
      ...item,
      assignedTo: item.assignedTo || undefined,
    }));
  }

  async getMaintenanceSchedules(): Promise<(MaintenanceSchedule & { equipment: Equipment })[]> {
    const schedules = await db
      .select({
        id: maintenanceSchedules.id,
        equipmentId: maintenanceSchedules.equipmentId,
        maintenanceType: maintenanceSchedules.maintenanceType,
        scheduledDate: maintenanceSchedules.scheduledDate,
        completedDate: maintenanceSchedules.completedDate,
        description: maintenanceSchedules.description,
        status: maintenanceSchedules.status,
        performedBy: maintenanceSchedules.performedBy,
        notes: maintenanceSchedules.notes,
        createdAt: maintenanceSchedules.createdAt,
        equipment: equipment,
      })
      .from(maintenanceSchedules)
      .innerJoin(equipment, eq(maintenanceSchedules.equipmentId, equipment.id))
      .orderBy(desc(maintenanceSchedules.scheduledDate));

    return schedules;
  }

  async getMaintenanceSchedule(id: number): Promise<(MaintenanceSchedule & { equipment: Equipment }) | undefined> {
    const [schedule] = await db
      .select({
        id: maintenanceSchedules.id,
        equipmentId: maintenanceSchedules.equipmentId,
        maintenanceType: maintenanceSchedules.maintenanceType,
        scheduledDate: maintenanceSchedules.scheduledDate,
        completedDate: maintenanceSchedules.completedDate,
        description: maintenanceSchedules.description,
        status: maintenanceSchedules.status,
        performedBy: maintenanceSchedules.performedBy,
        notes: maintenanceSchedules.notes,
        createdAt: maintenanceSchedules.createdAt,
        equipment: equipment,
      })
      .from(maintenanceSchedules)
      .innerJoin(equipment, eq(maintenanceSchedules.equipmentId, equipment.id))
      .where(eq(maintenanceSchedules.id, id));

    return schedule || undefined;
  }

  async createMaintenanceSchedule(insertSchedule: InsertMaintenanceSchedule): Promise<MaintenanceSchedule> {
    const [schedule] = await db
      .insert(maintenanceSchedules)
      .values(insertSchedule)
      .returning();
    return schedule;
  }

  async updateMaintenanceSchedule(id: number, updateSchedule: Partial<InsertMaintenanceSchedule>): Promise<MaintenanceSchedule> {
    const [schedule] = await db
      .update(maintenanceSchedules)
      .set(updateSchedule)
      .where(eq(maintenanceSchedules.id, id))
      .returning();
    return schedule;
  }

  async deleteMaintenanceSchedule(id: number): Promise<void> {
    await db.delete(maintenanceSchedules).where(eq(maintenanceSchedules.id, id));
  }

  async getUpcomingMaintenance(): Promise<(MaintenanceSchedule & { equipment: Equipment })[]> {
    const now = new Date();
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    const schedules = await db
      .select({
        id: maintenanceSchedules.id,
        equipmentId: maintenanceSchedules.equipmentId,
        maintenanceType: maintenanceSchedules.maintenanceType,
        scheduledDate: maintenanceSchedules.scheduledDate,
        completedDate: maintenanceSchedules.completedDate,
        description: maintenanceSchedules.description,
        status: maintenanceSchedules.status,
        performedBy: maintenanceSchedules.performedBy,
        notes: maintenanceSchedules.notes,
        createdAt: maintenanceSchedules.createdAt,
        equipment: equipment,
      })
      .from(maintenanceSchedules)
      .innerJoin(equipment, eq(maintenanceSchedules.equipmentId, equipment.id))
      .where(
        and(
          eq(maintenanceSchedules.status, "scheduled"),
          isNull(maintenanceSchedules.completedDate)
        )
      )
      .orderBy(maintenanceSchedules.scheduledDate);

    return schedules;
  }

  async getEquipmentHistory(equipmentId: number): Promise<(EquipmentHistory & { 
    fromEmployee?: Employee;
    toEmployee?: Employee;
    performedByUser: User;
  })[]> {
    const history = await db
      .select({
        id: equipmentHistory.id,
        equipmentId: equipmentHistory.equipmentId,
        action: equipmentHistory.action,
        fromEmployeeId: equipmentHistory.fromEmployeeId,
        toEmployeeId: equipmentHistory.toEmployeeId,
        performedBy: equipmentHistory.performedBy,
        description: equipmentHistory.description,
        createdAt: equipmentHistory.createdAt,
        fromEmployee: {
          id: employees.id,
          fullName: employees.fullName,
          email: employees.email,
          department: employees.department,
          position: employees.position,
          employeeId: employees.employeeId,
          status: employees.status,
          createdAt: employees.createdAt,
        },
        toEmployee: {
          // Use a separate alias for the to employee
          id: employees.id,
          fullName: employees.fullName,
          email: employees.email,
          department: employees.department,
          position: employees.position,
          employeeId: employees.employeeId,
          status: employees.status,
          createdAt: employees.createdAt,
        },
        performedByUser: users,
      })
      .from(equipmentHistory)
      .leftJoin(employees, eq(equipmentHistory.fromEmployeeId, employees.id))
      .innerJoin(users, eq(equipmentHistory.performedBy, users.id))
      .where(eq(equipmentHistory.equipmentId, equipmentId))
      .orderBy(desc(equipmentHistory.createdAt));

    return history.map(item => ({
      ...item,
      fromEmployee: item.fromEmployee || undefined,
      toEmployee: item.toEmployee || undefined,
    }));
  }

  async createEquipmentHistory(insertHistory: InsertEquipmentHistory): Promise<EquipmentHistory> {
    const [history] = await db
      .insert(equipmentHistory)
      .values(insertHistory)
      .returning();
    return history;
  }

  async getDashboardStats(): Promise<{
    totalEquipment: number;
    available: number;
    underMaintenance: number;
    upcomingMaintenance: number;
  }> {
    const [totalEquipmentResult] = await db
      .select({ count: count() })
      .from(equipment);

    const [availableResult] = await db
      .select({ count: count() })
      .from(equipment)
      .where(eq(equipment.status, "available"));

    const [underMaintenanceResult] = await db
      .select({ count: count() })
      .from(equipment)
      .where(eq(equipment.status, "maintenance"));

    const [upcomingMaintenanceResult] = await db
      .select({ count: count() })
      .from(maintenanceSchedules)
      .where(
        and(
          eq(maintenanceSchedules.status, "scheduled"),
          isNull(maintenanceSchedules.completedDate)
        )
      );

    return {
      totalEquipment: totalEquipmentResult.count,
      available: availableResult.count,
      underMaintenance: underMaintenanceResult.count,
      upcomingMaintenance: upcomingMaintenanceResult.count,
    };
  }
}

export const storage = new DatabaseStorage();
