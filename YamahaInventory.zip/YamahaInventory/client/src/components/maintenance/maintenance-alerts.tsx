import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Clock, Info } from "lucide-react";
import { format, isAfter, differenceInDays } from "date-fns";
import type { MaintenanceSchedule, Equipment } from "@shared/schema";

interface MaintenanceAlertsProps {
  maintenanceData: (MaintenanceSchedule & { equipment: Equipment })[];
}

export function MaintenanceAlerts({ maintenanceData }: MaintenanceAlertsProps) {
  // Sort maintenance by urgency (overdue first, then by scheduled date)
  const sortedMaintenance = [...maintenanceData].sort((a, b) => {
    const now = new Date();
    const aDate = new Date(a.scheduledDate);
    const bDate = new Date(b.scheduledDate);
    
    const aOverdue = isAfter(now, aDate);
    const bOverdue = isAfter(now, bDate);
    
    // Overdue items come first
    if (aOverdue && !bOverdue) return -1;
    if (!aOverdue && bOverdue) return 1;
    
    // Then sort by date
    return aDate.getTime() - bDate.getTime();
  });

  // Take only the first 3 most urgent items
  const urgentMaintenance = sortedMaintenance.slice(0, 3);

  const getAlertInfo = (schedule: MaintenanceSchedule) => {
    const now = new Date();
    const scheduledDate = new Date(schedule.scheduledDate);
    const daysDiff = differenceInDays(scheduledDate, now);
    
    if (daysDiff < 0) {
      return {
        type: "critical",
        icon: AlertTriangle,
        color: "bg-red-100 text-red-800",
        dotColor: "bg-red-400",
        message: `Overdue by ${Math.abs(daysDiff)} day${Math.abs(daysDiff) === 1 ? '' : 's'}`,
      };
    } else if (daysDiff <= 7) {
      return {
        type: "warning",
        icon: Clock,
        color: "bg-yellow-100 text-yellow-800",
        dotColor: "bg-yellow-400",
        message: `Due in ${daysDiff} day${daysDiff === 1 ? '' : 's'}`,
      };
    } else {
      return {
        type: "info",
        icon: Info,
        color: "bg-blue-100 text-blue-800",
        dotColor: "bg-blue-400",
        message: `Due in ${daysDiff} day${daysDiff === 1 ? '' : 's'}`,
      };
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Maintenance Alerts</CardTitle>
          <CardDescription>Upcoming and overdue maintenance schedules</CardDescription>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {urgentMaintenance.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No maintenance alerts</p>
          ) : (
            urgentMaintenance.map((schedule) => {
              const alertInfo = getAlertInfo(schedule);
              const Icon = alertInfo.icon;
              
              return (
                <div key={schedule.id} className="flex space-x-3">
                  <div className="flex-shrink-0">
                    <div className={`h-2 w-2 ${alertInfo.dotColor} rounded-full mt-2`}></div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-gray-900">
                      {schedule.equipment.itemName} - {schedule.maintenanceType}
                    </p>
                    <p className="text-sm text-gray-500">
                      {alertInfo.message}
                    </p>
                    <p className="text-xs text-gray-400">
                      Due: {format(new Date(schedule.scheduledDate), "MMM dd, yyyy")}
                    </p>
                  </div>
                  <div className="flex-shrink-0">
                    <Badge className={alertInfo.color}>
                      {alertInfo.type === "critical" ? "Critical" : 
                       alertInfo.type === "warning" ? "Warning" : "Info"}
                    </Badge>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
