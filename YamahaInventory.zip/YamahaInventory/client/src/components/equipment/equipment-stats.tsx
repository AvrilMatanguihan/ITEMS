import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Package, CheckCircle, Settings, Calendar } from "lucide-react";

interface DashboardStats {
  totalEquipment: number;
  available: number;
  underMaintenance: number;
  upcomingMaintenance: number;
}

export function EquipmentStats() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const statCards = [
    {
      title: "Total Equipment",
      value: stats?.totalEquipment ?? 0,
      icon: Package,
      color: "bg-blue-500",
      trend: "+12%",
      trendLabel: "from last month",
    },
    {
      title: "Available",
      value: stats?.available ?? 0,
      icon: CheckCircle,
      color: "bg-green-500",
      trend: "",
      trendLabel: "Ready for assignment",
    },
    {
      title: "Under Maintenance",
      value: stats?.underMaintenance ?? 0,
      icon: Settings,
      color: "bg-yellow-500",
      trend: "",
      trendLabel: "Scheduled repairs",
    },
    {
      title: "Upcoming Maintenance",
      value: stats?.upcomingMaintenance ?? 0,
      icon: Calendar,
      color: "bg-purple-500",
      trend: "",
      trendLabel: "Next 30 days",
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-5">
              <div className="h-20 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
      {statCards.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.title} className="overflow-hidden shadow rounded-lg">
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className={`w-8 h-8 ${stat.color} rounded-md flex items-center justify-center`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      {stat.title}
                    </dt>
                    <dd className="text-lg font-medium text-gray-900">
                      {stat.value.toLocaleString()}
                    </dd>
                  </dl>
                </div>
              </div>
            </CardContent>
            <div className="bg-gray-50 px-5 py-3">
              <div className="text-sm">
                {stat.trend && (
                  <span className="font-medium text-green-600">{stat.trend}</span>
                )}
                {stat.trend && <span className="text-gray-500"> </span>}
                <span className="text-gray-500">{stat.trendLabel}</span>
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
