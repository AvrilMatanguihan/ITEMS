import { Sidebar } from "@/components/layout/sidebar";
import { Topbar } from "@/components/layout/topbar";
import { EquipmentTable } from "@/components/equipment/equipment-table";

export default function EquipmentPage() {
  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      <Sidebar />
      
      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        <Topbar />
        
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              {/* Page header */}
              <div className="md:flex md:items-center md:justify-between mb-8">
                <div className="flex-1 min-w-0">
                  <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                    Equipment Management
                  </h2>
                  <p className="mt-1 text-sm text-gray-500">
                    Manage and track all IT equipment in the organization
                  </p>
                </div>
              </div>

              {/* Equipment Table */}
              <EquipmentTable showFilters={true} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
