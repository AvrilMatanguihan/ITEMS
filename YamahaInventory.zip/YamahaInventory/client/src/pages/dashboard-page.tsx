import { Sidebar } from "@/components/layout/sidebar";
import { Topbar } from "@/components/layout/topbar";
import { EquipmentStats } from "@/components/equipment/equipment-stats";
import { EquipmentTable } from "@/components/equipment/equipment-table";
import { MaintenanceAlerts } from "@/components/maintenance/maintenance-alerts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Database, Loader2 } from "lucide-react";
import type { Equipment, Employee, MaintenanceSchedule } from "@shared/schema";

export default function DashboardPage() {
  const { toast } = useToast();
  
  const { data: recentEquipment = [] } = useQuery<(Equipment & { assignedTo?: Employee })[]>({
    queryKey: ["/api/equipment"],
  });

  const { data: upcomingMaintenance = [] } = useQuery<(MaintenanceSchedule & { equipment: Equipment })[]>({
    queryKey: ["/api/maintenance/upcoming"],
  });

  const seedMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/seed");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/equipment"] });
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/maintenance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/maintenance/upcoming"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Sample data has been added to the system",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Get the 3 most recent equipment
  const recentEquipmentItems = recentEquipment.slice(0, 3);

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      <Sidebar />
      
      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        <Topbar />
        
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
              {/* Page header */}
              <div className="md:flex md:items-center md:justify-between mb-8">
                <div className="flex-1 min-w-0">
                  <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                    Dashboard
                  </h2>
                  <p className="mt-1 text-sm text-gray-500">
                    Overview of IT equipment and system status
                  </p>
                </div>
                {recentEquipment.length === 0 && (
                  <div className="mt-4 flex md:mt-0 md:ml-4">
                    <Button
                      onClick={() => seedMutation.mutate()}
                      disabled={seedMutation.isPending}
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700"
                    >
                      {seedMutation.isPending && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      <Database className="mr-2 h-4 w-4" />
                      Add Sample Data
                    </Button>
                  </div>
                )}
              </div>

              {/* Stats Grid */}
              <EquipmentStats />

              {/* Content Grid */}
              <div className="grid grid-cols-1 gap-6 lg:grid-cols-2 mt-8">
                {/* Recent Equipment */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Recent Equipment</CardTitle>
                      <CardDescription>Latest equipment added to the system</CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentEquipmentItems.length === 0 ? (
                        <p className="text-gray-500 text-center py-4">No equipment found</p>
                      ) : (
                        recentEquipmentItems.map((item) => (
                          <div key={item.id} className="flex items-center space-x-4">
                            <div className="flex-shrink-0">
                              <div className="h-8 w-8 bg-gray-200 rounded-lg flex items-center justify-center">
                                <svg className="h-5 w-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"/>
                                </svg>
                              </div>
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate">
                                {item.itemName}
                              </p>
                              <p className="text-sm text-gray-500">
                                SN: {item.serialNumber}
                              </p>
                            </div>
                            <div className="flex-shrink-0">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                item.status === 'active' ? 'bg-green-100 text-green-800' :
                                item.status === 'available' ? 'bg-blue-100 text-blue-800' :
                                item.status === 'maintenance' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'
                              }`}>
                                {item.status === 'active' ? 'Active' :
                                 item.status === 'available' ? 'Available' :
                                 item.status === 'maintenance' ? 'Under Repair' :
                                 'Disposed'}
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Maintenance Alerts */}
                <MaintenanceAlerts maintenanceData={upcomingMaintenance} />
              </div>

              {/* Equipment Table */}
              <div className="mt-8">
                <EquipmentTable />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
