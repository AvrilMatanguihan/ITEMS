import { pgTable, text, serial, integer, boolean, timestamp, date, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("it_staff"), // admin, it_staff
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  department: text("department").notNull(),
  position: text("position").notNull(),
  employeeId: text("employee_id").notNull().unique(),
  status: text("status").notNull().default("active"), // active, inactive
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const equipment = pgTable("equipment", {
  id: serial("id").primaryKey(),
  itemName: text("item_name").notNull(),
  brand: text("brand").notNull(),
  model: text("model").notNull(),
  category: text("category").notNull(), // laptop, desktop, monitor, phone, tablet, printer, server, networking
  serialNumber: text("serial_number").notNull().unique(),
  assignedToId: integer("assigned_to_id").references(() => employees.id),
  condition: text("condition").notNull(), // new, good, fair, poor
  status: text("status").notNull(), // active, available, maintenance, disposed
  purchaseDate: date("purchase_date"),
  remarks: text("remarks"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const maintenanceSchedules = pgTable("maintenance_schedules", {
  id: serial("id").primaryKey(),
  equipmentId: integer("equipment_id").references(() => equipment.id).notNull(),
  maintenanceType: text("maintenance_type").notNull(), // preventive, repair, inspection
  scheduledDate: date("scheduled_date").notNull(),
  completedDate: date("completed_date"),
  description: text("description").notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled, in_progress, completed, cancelled
  performedBy: text("performed_by"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const equipmentHistory = pgTable("equipment_history", {
  id: serial("id").primaryKey(),
  equipmentId: integer("equipment_id").references(() => equipment.id).notNull(),
  action: text("action").notNull(), // assigned, returned, maintenance, status_change
  fromEmployeeId: integer("from_employee_id").references(() => employees.id),
  toEmployeeId: integer("to_employee_id").references(() => employees.id),
  performedBy: integer("performed_by").references(() => users.id).notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  equipmentHistory: many(equipmentHistory),
}));

export const employeesRelations = relations(employees, ({ many }) => ({
  assignedEquipment: many(equipment),
  historyFrom: many(equipmentHistory, { relationName: "historyFrom" }),
  historyTo: many(equipmentHistory, { relationName: "historyTo" }),
}));

export const equipmentRelations = relations(equipment, ({ one, many }) => ({
  assignedTo: one(employees, {
    fields: [equipment.assignedToId],
    references: [employees.id],
  }),
  maintenanceSchedules: many(maintenanceSchedules),
  history: many(equipmentHistory),
}));

export const maintenanceSchedulesRelations = relations(maintenanceSchedules, ({ one }) => ({
  equipment: one(equipment, {
    fields: [maintenanceSchedules.equipmentId],
    references: [equipment.id],
  }),
}));

export const equipmentHistoryRelations = relations(equipmentHistory, ({ one }) => ({
  equipment: one(equipment, {
    fields: [equipmentHistory.equipmentId],
    references: [equipment.id],
  }),
  fromEmployee: one(employees, {
    fields: [equipmentHistory.fromEmployeeId],
    references: [employees.id],
    relationName: "historyFrom",
  }),
  toEmployee: one(employees, {
    fields: [equipmentHistory.toEmployeeId],
    references: [employees.id],
    relationName: "historyTo",
  }),
  performedByUser: one(users, {
    fields: [equipmentHistory.performedBy],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertEmployeeSchema = createInsertSchema(employees).omit({
  id: true,
  createdAt: true,
});

export const insertEquipmentSchema = createInsertSchema(equipment).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMaintenanceScheduleSchema = createInsertSchema(maintenanceSchedules).omit({
  id: true,
  createdAt: true,
});

export const insertEquipmentHistorySchema = createInsertSchema(equipmentHistory).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;

export type Equipment = typeof equipment.$inferSelect;
export type InsertEquipment = z.infer<typeof insertEquipmentSchema>;

export type MaintenanceSchedule = typeof maintenanceSchedules.$inferSelect;
export type InsertMaintenanceSchedule = z.infer<typeof insertMaintenanceScheduleSchema>;

export type EquipmentHistory = typeof equipmentHistory.$inferSelect;
export type InsertEquipmentHistory = z.infer<typeof insertEquipmentHistorySchema>;
